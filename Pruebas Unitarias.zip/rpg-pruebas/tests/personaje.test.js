const Personaje = require('../src/personaje');

describe('Personaje', () => {

  // Caso 1 — Vida inicial completa
  test('personaje recién creado tiene vida igual a su vida máxima', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act
    const vida = heroe.vidaActual;

    // Assert
    expect(vida).toBe(heroe.vidaMaxima);
  });

  // Caso 2 — recibirDanio reduce la vida correctamente
  test('recibirDanio reduce la vida en la cantidad exacta del daño', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act
    heroe.recibirDanio(30);

    // Assert
    expect(heroe.vidaActual).toBe(70);
  });

  // Caso 3 — recibirDanio letal deja vida en 0
  test('recibirDanio con valor letal deja la vida en 0, no en negativo', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act
    heroe.recibirDanio(200);

    // Assert
    expect(heroe.vidaActual).toBe(0);
  });

  // Caso 4 — recibirDanio negativo lanza error
  test('recibirDanio con valor negativo lanza un error', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act & Assert
    expect(() => heroe.recibirDanio(-10)).toThrow();
  });

  // Caso 5 — curar aumenta la vida correctamente
  test('curar aumenta la vida en la cantidad indicada', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);
    heroe.recibirDanio(40);

    // Act
    heroe.curar(20);

    // Assert
    expect(heroe.vidaActual).toBe(80);
  });

  // Caso 6 — curar no excede la vida máxima
  test('curar no puede exceder la vida máxima del personaje', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);
    heroe.recibirDanio(10);

    // Act
    heroe.curar(500);

    // Assert
    expect(heroe.vidaActual).toBe(heroe.vidaMaxima);
  });

  // Caso 7 — estaVivo retorna true cuando hay vida
  test('estaVivo retorna true si la vida actual es mayor a 0', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act
    const vivo = heroe.estaVivo();

    // Assert
    expect(vivo).toBeTruthy();
  });

  // Caso 8 — estaVivo retorna false cuando vida es 0
  test('estaVivo retorna false si la vida actual es 0', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);
    heroe.recibirDanio(100);

    // Act
    const vivo = heroe.estaVivo();

    // Assert
    expect(vivo).toBeFalsy();
  });

  // Caso 9 — subirNivel restaura la vida y aumenta stats
  test('subirNivel incrementa el nivel y restaura la vida al nuevo máximo', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);
    heroe.recibirDanio(50);

    // Act
    heroe.subirNivel();

    // Assert: nivel incrementado y vida restaurada al nuevo máximo
    expect(heroe.nivel).toBe(2);
    expect(heroe.vidaActual).toBe(heroe.vidaMaxima);
  });

  // Caso 10 — ganarExperiencia sube de nivel al alcanzar el umbral
  test('ganarExperiencia sube de nivel cuando la XP alcanza el umbral requerido', () => {
    // Arrange
    const heroe = new Personaje('Aria', 100, 15, 5);

    // Act — nivel 1 necesita 100 XP para subir
    heroe.ganarExperiencia(100);

    // Assert
    expect(heroe.nivel).toBe(2);
  });

});
