const { calcularRecompensa } = require('../src/nivel');

describe('calcularRecompensa', () => {

  // Caso 1 — Mismo nivel: multiplicador 1.0
  test('mismo nivel (diferencia 0): aplica multiplicador 1.0 y retorna xpBase completa', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 5;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(100);
  });

  // Caso 2 — Enemigo 1-2 niveles abajo: multiplicador 0.75
  test('enemigo 2 niveles abajo (diferencia -2, frontera): aplica multiplicador 0.75', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 3;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(75);
  });

  // Caso 3 — Enemigo 3+ niveles abajo: multiplicador 0.5 (frontera exacta -3)
  test('enemigo exactamente 3 niveles abajo (diferencia -3, frontera): aplica multiplicador 0.5', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 2;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(50);
  });

  // Caso 4 — Enemigo 1-2 niveles arriba: multiplicador 1.5 (frontera exacta +2)
  test('enemigo exactamente 2 niveles arriba (diferencia 2, frontera): aplica multiplicador 1.5', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 7;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(150);
  });

  // Caso 5 — Enemigo 3+ niveles arriba: multiplicador 2.0 (frontera exacta +3)
  test('enemigo exactamente 3 niveles arriba (diferencia 3, frontera): aplica multiplicador 2.0', () => {
    // Arrange
    const xpBase = 100;
    const nivelEnemigo = 8;
    const nivelPersonaje = 5;

    // Act
    const xp = calcularRecompensa(xpBase, nivelEnemigo, nivelPersonaje);

    // Assert
    expect(xp).toBe(200);
  });

});
