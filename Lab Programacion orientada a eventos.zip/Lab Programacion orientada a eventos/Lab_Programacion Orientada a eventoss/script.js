console.log(document);

const paragraph1 = document.getElementById("para1");
const list = document.querySelector(".list");
const listItems = document.querySelectorAll("ul > li");

console.log(paragraph1);
console.log(paragraph1.textContent);
console.log(list);

listItems.forEach((item) => {
  console.log(item);
});

document.getElementById("read-paragraph").addEventListener("click", () => {
  console.log(paragraph1.textContent);
});

document.getElementById("highlight-list").addEventListener("click", () => {
  list.style.color = "blue";
});

document.getElementById("create-web-list").addEventListener("click", () => {
  const dynamicZone = document.getElementById("dynamic-zone");
  dynamicZone.textContent = "";

  const title = document.createElement("h3");
  title.textContent = "Elementos que se utilizan en desarrollo web:";

  const unorderedList = document.createElement("ul");

  const element1 = document.createElement("li");
  element1.textContent = "HTML";
  unorderedList.appendChild(element1);

  const element2 = document.createElement("li");
  element2.textContent = "CSS";
  unorderedList.appendChild(element2);

  const element3 = document.createElement("li");
  element3.textContent = "JS";
  unorderedList.appendChild(element3);

  dynamicZone.appendChild(title);
  dynamicZone.appendChild(unorderedList);
});

const colorTitle = document.querySelector("#color-title");

document.getElementById("change-color").addEventListener("click", () => {
  colorTitle.style.color = "blue";
  colorTitle.textContent = "Ohh, me cambiaron a azul.";
  console.log(colorTitle);
});

document.getElementById("reset-color").addEventListener("click", () => {
  colorTitle.style.color = "";
  colorTitle.textContent = "Hola, soy un texto en color negro.";
});

const button = document.getElementById("btn");

button.addEventListener("click", () => {
  alert("Gracias por el click");
});
