const filesystem = require('fs');

console.log('Hola Mundo');
console.log('Version de Node.js:', process.version);

const calcularPromedio = (numeros) => {
  if (!Array.isArray(numeros) || numeros.length === 0) {
    return 0;
  }

  const suma = numeros.reduce((acumulado, numero) => acumulado + numero, 0);
  return suma / numeros.length;
};

const escribirTextoEnArchivo = (texto, nombreArchivo = 'mensaje.txt') => {
  filesystem.writeFileSync(nombreArchivo, texto);
  return `Se escribio el texto en ${nombreArchivo}`;
};

const calcularAreaTriangulo = (base, altura) => {
  return (base * altura) / 2;
};

const numeros = [8, 9, 10, 7, 6, 10];
const texto = 'Hola mundo desde node y el modulo fs';

console.log('\nEjercicio 1: promedio');
console.log('Arreglo:', numeros);
console.log('Promedio:', calcularPromedio(numeros));

console.log('\nEjercicio 2: escribir archivo con fs');
console.log(escribirTextoEnArchivo(texto, 'hola.txt'));
console.log('Contenido escrito:', filesystem.readFileSync('hola.txt', 'utf8'));

console.log('\nEjercicio 3: problema en JavaScript sobre Node');
console.log('Problema elegido: calcular el area de un triangulo');
console.log('Base: 12');
console.log('Altura: 5');
console.log('Area:', calcularAreaTriangulo(12, 5));

console.log('\nAsync sort: los numeros se imprimen segun su tiempo de espera');
const arreglo = [5000, 60, 90, 100, 10, 20, 10000, 0, 120, 2000, 340, 1000, 50];

for (let item of arreglo) {
  setTimeout(() => {
    console.log(item);
  }, item);
}

const teHackie = () => {
  console.log('jojo te hackie');
};

setTimeout(teHackie, 7000);
console.log('Esta linea se ejecuta antes que la funcion con setTimeout.');
