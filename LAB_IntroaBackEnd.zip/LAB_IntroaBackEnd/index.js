const http = require('http');
const filesystem = require('fs');
const path = require('path');

const port = 3000;

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

const server = http.createServer((request, response) => {
  const requestedUrl = request.url === '/' ? '/index.html' : request.url;
  const safePath = path.normalize(decodeURIComponent(requestedUrl)).replace(/^(\.\.[/\\])+/, '');
  const filePath = path.join(__dirname, safePath);

  filesystem.readFile(filePath, (error, content) => {
    if (error) {
      response.statusCode = error.code === 'ENOENT' ? 404 : 500;
      response.setHeader('Content-Type', 'text/plain; charset=utf-8');
      response.end(error.code === 'ENOENT' ? 'Archivo no encontrado' : 'Error interno del servidor');
      return;
    }

    const extension = path.extname(filePath).toLowerCase();

    response.statusCode = 200;
    response.setHeader('Content-Type', mimeTypes[extension] || 'application/octet-stream');
    response.end(content);
  });
});

if (require.main === module) {
  server.listen(port, () => {
    console.log(`Servidor ejecutandose en http://localhost:${port}`);
  });
}

module.exports = server;
