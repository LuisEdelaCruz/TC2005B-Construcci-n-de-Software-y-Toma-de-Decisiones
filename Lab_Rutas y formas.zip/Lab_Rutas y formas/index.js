const http = require('http');
const path = require('path');
const fs = require('fs');

const server = http.createServer((request, response) => {
    console.log(`${request.method} ${request.url}`);

    switch (request.url) {
        case "/":
            response.setHeader('Content-Type', 'text/plain; charset=utf-8');
            response.write("URL index /");
            response.end();
            break;

        case "/test_json":
            if (request.method == "GET") {
                response.setHeader('Content-Type', 'application/json; charset=utf-8');
                response.write(JSON.stringify({ code: 200, msg: "Ok GET" }));
                response.end();
            } else if (request.method == "POST") {
                response.setHeader('Content-Type', 'application/json; charset=utf-8');
                response.write(JSON.stringify({ code: 200, msg: "Ok POST" }));
                response.end();
            }
            break;

        case "/test_html":
            response.setHeader('Content-Type', 'text/html; charset=utf-8');
            response.write(`
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="utf-8">
                    <title>Codigo en HTML</title>
                </head>
                <body>
                    <h1>Hola mundo desde Node.js</h1>
                </body>
                </html>
            `);
            response.end();
            break;

        case "/form_method":
            if (request.method == "GET") {
                response.setHeader('Content-Type', 'text/html; charset=utf-8');
                const html = fs.readFileSync(path.resolve(__dirname, './form.html'), 'utf8');
                response.write(html);
                response.end();
            } else if (request.method == "POST") {
                let body = [];

                request
                    .on('data', chunk => {
                        body.push(chunk);
                    })
                    .on('end', () => {
                        body = Buffer.concat(body).toString();

                        const datos = new URLSearchParams(body);
                        const indice = Number(datos.get('indice'));
                        const imprimir = datos.get('imprimir');
                        const contenido = [
                            `Fecha: ${new Date().toISOString()}`,
                            `Indice: ${indice}`,
                            `Valor a imprimir: ${imprimir}`,
                            ''
                        ].join('\n');

                        for (let i = 1; i <= indice; i++) {
                            console.log(imprimir);
                        }

                        fs.appendFile(path.resolve(__dirname, './datos.txt'), contenido, error => {
                            response.setHeader('Content-Type', 'application/json; charset=utf-8');

                            if (error) {
                                response.statusCode = 500;
                                response.write(JSON.stringify({ code: 500, msg: "No se pudieron guardar los datos" }));
                            } else {
                                response.statusCode = 200;
                                response.write(JSON.stringify({ code: 200, msg: "Datos guardados correctamente" }));
                            }

                            response.end();
                        });
                    });
            }
            break;

        default:
            response.statusCode = 404;
            response.setHeader('Content-Type', 'text/plain; charset=utf-8');
            response.end('404 - Ruta no encontrada');
            break;
    }
});

server.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});
