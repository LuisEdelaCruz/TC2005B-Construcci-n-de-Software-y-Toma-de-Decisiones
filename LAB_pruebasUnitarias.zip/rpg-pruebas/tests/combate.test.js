const { calcularDanio } = require('../src/combate');

describe('calcularDanio', () => {

  // Caso 1 - Daño normal: ataque mayor que defensa
  test('daño normal: retorna la diferencia entre ataque y defensa cuando ataque > defensa', () => {
    // Arrange
    const atacante = { ataque: 15 };
    const defensor = { defensa: 5 };

    // Act
    const danio = calcularDanio(atacante, defensor);

    // Assert
    expect(danio).toBe(10);
  });

  // Caso 2 - Frontera: ataque igual a defensa retorna el mínimo garantizado
  test('frontera: retorna 1 cuando el ataque es igual a la defensa', () => {
    // Arrange
    const atacante = { ataque: 10 };
    const defensor = { defensa: 10 };

    // Act
    const danio = calcularDanio(atacante, defensor);

    // Assert
    expect(danio).toBe(1);
  });

  // Caso 3 - Defensa mayor que ataque retorna el mínimo garantizado
  test('retorna 1 cuando la defensa supera al ataque, nunca daño negativo', () => {
    // Arrange
    const atacante = { ataque: 5 };
    const defensor = { defensa: 20 };

    // Act
    const danio = calcularDanio(atacante, defensor);

    // Assert
    expect(danio).toBe(1);
  });

  // Caso 4 - Ataque y defensa ambos en cero retorna el mínimo garantizado
  test('retorna 1 cuando ataque y defensa son ambos 0', () => {
    // Arrange
    const atacante = { ataque: 0 };
    const defensor = { defensa: 0 };

    // Act
    const danio = calcularDanio(atacante, defensor);

    // Assert
    expect(danio).toBe(1);
  });

});
