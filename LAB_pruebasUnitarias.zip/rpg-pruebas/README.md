# 🎮 RPG por turnos - Proyecto base de Pruebas

Proyecto educativo para el módulo de **Pruebas de Software** de TC2005B.

---

## 📁 Estructura del proyecto

```
rpg-pruebas/
├── src/                    Lógica del juego (lo que se prueba con Jest)
│   ├── personaje.js        Clase Personaje (vida, curación, niveles)
│   ├── enemigo.js          Clase Enemigo
│   ├── combate.js          Sistema de combate (calcular daño, turnos)
│   ├── nivel.js            Sistema de experiencia
│   └── index.js            Demo en consola
│
├── tests/                  Pruebas automatizadas (Jest)
│   └── ejemplo.test.js     Test de muestra del patrón AAA
│
├── public/                 Interfaz web del juego
│   ├── index.html
│   ├── styles.css
│   └── game.js
│
├── package.json
└── README.md
```

---

## 🚀 Cómo ejecutar

```bash
# Instalar dependencias
npm install

# Correr el demo en consola
npm start

# Correr las pruebas
npm test

# Correr pruebas en modo watch (se vuelven a correr al guardar)
npm run test:watch

# Correr pruebas con reporte de cobertura
npm run test:coverage

# Abrir la UI web
npm run ui
# Luego abrir el link que muestra (típicamente http://localhost:3000)
```

---

## 📚 ¿Qué van a aprender con este proyecto?

### Sesión 1 — Fundamentos y diseño de casos de prueba
Diseño en papel de casos de prueba para las funciones del juego, aplicando:
- Clases de equivalencia
- Valores frontera

### Sesión 2 — Pruebas unitarias con Jest
Escribirán pruebas automatizadas para:
- `Personaje.recibirDanio()`
- `Personaje.curar()`
- `Personaje.estaVivo()`
- `Personaje.subirNivel()`
- `calcularDanio()` de combate
- `calcularRecompensa()` de nivel

### Sesión 3 — Integración + Pruebas en voz alta
- Pruebas de integración: `combateCompleto()` orquesta varios módulos
- Pruebas con usuarios usando la UI del juego (carpeta `public/`)

---

## 🎯 Funciones que serán probadas

| Módulo | Función | ¿Qué hace? |
|---|---|---|
| `personaje.js` | `recibirDanio(d)` | Reduce vida, no baja de 0 |
| `personaje.js` | `curar(c)` | Aumenta vida, no excede vidaMaxima |
| `personaje.js` | `estaVivo()` | Devuelve true si vidaActual > 0 |
| `personaje.js` | `ganarExperiencia(xp)` | Suma XP y sube de nivel si corresponde |
| `personaje.js` | `subirNivel()` | Aumenta stats y restaura vida |
| `enemigo.js` | `recibirDanio(d)` | Igual que Personaje |
| `combate.js` | `calcularDanio(a, d)` | Devuelve daño (mínimo 1) |
| `combate.js` | `ejecutarTurno(a, d)` | Ejecuta un turno completo |
| `combate.js` | `combateCompleto(p, e)` | Combate hasta que uno muera |
| `nivel.js` | `experienciaParaNivel(n)` | XP acumulada para un nivel |
| `nivel.js` | `calcularRecompensa(xp, nE, nP)` | XP final según diferencia de niveles |

---

## 🧪 Patrón AAA (Arrange-Act-Assert)

Todas las pruebas siguen este patrón:

```javascript
test('descripción clara de qué se prueba', () => {
  // Arrange: preparar datos y objetos
  const heroe = new Personaje('Aria', 100, 15, 5);

  // Act: ejecutar la acción a probar
  heroe.recibirDanio(30);

  // Assert: verificar el resultado
  expect(heroe.vidaActual).toBe(70);
});
```

---

## Análisis de cobertura — Lab 27 (Sesión 2)

Reporte obtenido con `npm test -- --coverage`:

```
--------------|---------|----------|---------|---------|-------------------
File          | % Stmts | % Branch | % Funcs | % Lines | Uncovered Line #s
--------------|---------|----------|---------|---------|-------------------
All files     |   58.13 |    50.87 |      75 |   59.52 |
 personaje.js |   85.71 |    68.75 |     100 |   85.71 | 13,16,19,52,81
 nivel.js     |   53.57 |    60.00 |    50.0 |   55.55 | 18-32,53,56
 combate.js   |   21.73 |    28.57 |   33.33 |   22.72 | 19,22,35-75
--------------|---------|----------|---------|---------|-------------------
Tests:        20 passed, 20 total
```

`personaje.js` quedó con la cobertura más alta porque los 10 tests ejercitan directamente cada método de la clase, `recibirDanio`, `curar`, `estaVivo`, `subirNivel` y `ganarExperiencia`, garantizando que todas las funciones se invocan al menos una vez. La línea 35 de `combate.js`, llamó la atención porque marca el comienzo de un bloque de 40 líneas completamente en rojo, lo que evidencia que `ejecutarTurno` y `combateCompleto` no fueron tocadas en ningún test. La decisión correcta es dejarlas como código de integración aceptable para esta sesión y cubrirlas en la Sesión 3 con instancias reales de `Personaje` y `Enemigo`, ya que su propósito es orquestar módulos, no lógica unitaria aislada.

---

## 📜 Licencia

Material educativo para TC2005B - Tecnológico de Monterrey.
