const fs = require('fs');

function promedio(numeros) {
    if (numeros.length === 0) {
        return 0;
    }

    let suma = 0;
    for (const numero of numeros) {
        suma += numero;
    }

    return suma / numeros.length;
}

function escribirArchivo(texto) {
    fs.writeFileSync('hola.txt', texto);
    console.log('Archivo hola.txt escrito correctamente.');
}

function convertirCelsiusAFahrenheit(celsius) {
    return (celsius * 9 / 5) + 32;
}

const numeros = [5000, 60, 90, 100, 10, 20, 10000, 0, 120, 2000, 340, 1000, 50];
const texto = 'Hola mundo desde node y el modulo fs';
const temperaturaCelsius = 25;

console.log('Promedio:', promedio(numeros));
escribirArchivo(texto);
console.log(`${temperaturaCelsius} grados Celsius equivalen a ${convertirCelsiusAFahrenheit(temperaturaCelsius)} grados Fahrenheit.`);
