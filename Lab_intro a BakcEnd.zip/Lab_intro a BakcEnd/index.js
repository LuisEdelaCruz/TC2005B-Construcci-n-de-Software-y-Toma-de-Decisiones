const http = require('http');
const fs = require('fs');

const server = http.createServer((request, response) => {
    console.log(`Peticion recibida: ${request.url}`);

    if (request.url === '/' || request.url === '/pagina') {
        const pagina = fs.readFileSync('pagina.html', 'utf8');
        response.setHeader('Content-Type', 'text/html; charset=utf-8');
        response.write(pagina);
        response.end();
        return;
    }

    response.statusCode = 404;
    response.setHeader('Content-Type', 'text/plain; charset=utf-8');
    response.end('Pagina no encontrada');
});

server.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});
