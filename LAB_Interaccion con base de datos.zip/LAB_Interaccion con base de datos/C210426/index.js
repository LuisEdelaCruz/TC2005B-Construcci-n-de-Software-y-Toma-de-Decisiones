const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();

const gameRoutes = require('./routes/game.routes.js');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (req, res) => {
    res.status(200).json({ message: 'OK' });
});

app.use('/games', gameRoutes);

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});