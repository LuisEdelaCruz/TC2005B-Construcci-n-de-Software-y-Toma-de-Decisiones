const log = console.log;
const myForm = document.getElementById("myForm");
const submitButton = document.getElementById("submitButton");
const updateProductsButton = document.getElementById("updateProductsButton");
const wrapper = document.getElementById("wrapper");
const codeResult = document.getElementById("codeResult");

let gridTable = null;

class Product {
  constructor(id, name, price) {
    this.id = id;
    this.name = name;
    this.price = price;
  }
}

function generateProduct() {
  const idInput = myForm.elements.id;
  const nameInput = myForm.elements.name;
  const priceInput = myForm.elements.price;

  const id = Number(idInput.value);
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);

  let msg = "Created product";

  if (!Number.isFinite(id)) {
    msg = "Id is empty";
  } else if (!name) {
    msg = "Name is empty";
  } else if (!Number.isFinite(price)) {
    msg = "Price is empty";
  }

  if (msg !== "Created product") {
    return { product: null, msg };
  }

  return { product: new Product(id, name, price), msg };
}

const getGridRows = (data) => {
  const products = Array.isArray(data.products) ? data.products : [];

  return products.map((product) => [
    product.id,
    product.name,
    product.price,
  ]);
};

function renderGridTable() {
  if (!wrapper || typeof gridjs === "undefined") {
    return false;
  }

  if (!gridTable) {
    gridTable = new gridjs.Grid({
      columns: ["Id", "Name", "Price"],
      pagination: true,
      search: true,
      sort: true,
      server: {
        url: "/products",
        then: (data) => getGridRows(data),
      },
    });

    gridTable.render(wrapper);
    return true;
  }

  gridTable
    .updateConfig({
      server: {
        url: "/products",
        then: (data) => getGridRows(data),
      },
    })
    .forceRender();

  return true;
}

async function getProducts() {
  const response = await fetch("/products");

  if (!response.ok) {
    throw new Error(`HTTP-Error: ${response.status}`);
  }

  const json = await response.json();
  return Array.isArray(json.products) ? json.products : [];
}

async function loadProducts() {
  const products = await getProducts();

  if (codeResult) {
    codeResult.textContent = "";
  }

  if (!renderGridTable()) {
    wrapper.innerHTML = JSON.stringify(products);
  }

  return products;
}

async function addProduct(product) {
  const response = await fetch("/add_product", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(product),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.msg || response.statusText);
  }

  log("Product added successfully:", data);
  return data;
}

window.addEventListener("load", () => {
  loadProducts().catch((error) => {
    alert(error.message);
  });
});

myForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const result = generateProduct();

  if (!result.product) {
    if (codeResult) {
      codeResult.textContent = result.msg;
    }
    return;
  }

  submitButton.disabled = true;

  try {
    await addProduct(result.product);
    myForm.reset();
    await loadProducts();
  } catch (error) {
    alert(`Error adding product: ${error.message}`);
  } finally {
    submitButton.disabled = false;
  }
});

updateProductsButton.addEventListener("click", () => {
  loadProducts().catch((error) => {
    alert(error.message);
  });
});

setInterval(() => {
  loadProducts().catch((error) => {
    log(error);
  });
}, 5000);
